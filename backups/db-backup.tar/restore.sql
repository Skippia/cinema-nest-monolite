--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0 (Debian 16.0-1.pgdg120+1)
-- Dumped by pg_dump version 16.0 (Debian 16.0-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cinema;
--
-- Name: cinema; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE cinema WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE cinema OWNER TO postgres;

\connect cinema

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AuthProviderEnum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AuthProviderEnum" AS ENUM (
    'LOCAL',
    'GMAIL',
    'GITHUB',
    'FACEBOOK'
);


ALTER TYPE public."AuthProviderEnum" OWNER TO postgres;

--
-- Name: CurrencyEnum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CurrencyEnum" AS ENUM (
    'USD',
    'EUR',
    'BYN',
    'RUB'
);


ALTER TYPE public."CurrencyEnum" OWNER TO postgres;

--
-- Name: GenderEnum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."GenderEnum" AS ENUM (
    'MALE',
    'FEMALE'
);


ALTER TYPE public."GenderEnum" OWNER TO postgres;

--
-- Name: LanguageEnum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LanguageEnum" AS ENUM (
    'EN',
    'RU'
);


ALTER TYPE public."LanguageEnum" OWNER TO postgres;

--
-- Name: RoleEnum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RoleEnum" AS ENUM (
    'USER',
    'ADMIN',
    'OWNER'
);


ALTER TYPE public."RoleEnum" OWNER TO postgres;

--
-- Name: TypeSeatEnum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TypeSeatEnum" AS ENUM (
    'SEAT',
    'VIP',
    'LOVE'
);


ALTER TYPE public."TypeSeatEnum" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Booking" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "totalPrice" double precision NOT NULL,
    currency public."CurrencyEnum" NOT NULL,
    "movieSessionId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Booking" OWNER TO postgres;

--
-- Name: Booking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Booking_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Booking_id_seq" OWNER TO postgres;

--
-- Name: Booking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Booking_id_seq" OWNED BY public."Booking".id;


--
-- Name: Cinema; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Cinema" (
    id integer NOT NULL,
    name text NOT NULL,
    address text NOT NULL,
    city text NOT NULL
);


ALTER TABLE public."Cinema" OWNER TO postgres;

--
-- Name: CinemaHall; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CinemaHall" (
    id integer NOT NULL,
    "cinemaId" integer NOT NULL,
    "hallType" text NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."CinemaHall" OWNER TO postgres;

--
-- Name: CinemaHall_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CinemaHall_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CinemaHall_id_seq" OWNER TO postgres;

--
-- Name: CinemaHall_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CinemaHall_id_seq" OWNED BY public."CinemaHall".id;


--
-- Name: Cinema_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Cinema_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Cinema_id_seq" OWNER TO postgres;

--
-- Name: Cinema_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Cinema_id_seq" OWNED BY public."Cinema".id;


--
-- Name: MovieOnCinema; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MovieOnCinema" (
    "cinemaId" integer NOT NULL,
    "movieId" integer NOT NULL
);


ALTER TABLE public."MovieOnCinema" OWNER TO postgres;

--
-- Name: MovieRecord; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MovieRecord" (
    id integer NOT NULL,
    "imdbId" text NOT NULL
);


ALTER TABLE public."MovieRecord" OWNER TO postgres;

--
-- Name: MovieRecord_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MovieRecord_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MovieRecord_id_seq" OWNER TO postgres;

--
-- Name: MovieRecord_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MovieRecord_id_seq" OWNED BY public."MovieRecord".id;


--
-- Name: MovieSession; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MovieSession" (
    id integer NOT NULL,
    price double precision NOT NULL,
    currency public."CurrencyEnum" DEFAULT 'USD'::public."CurrencyEnum" NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "movieId" integer NOT NULL,
    "cinemaHallId" integer NOT NULL
);


ALTER TABLE public."MovieSession" OWNER TO postgres;

--
-- Name: MovieSessionMultiFactor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MovieSessionMultiFactor" (
    id integer NOT NULL,
    "movieSessionId" integer NOT NULL,
    "typeSeatId" integer NOT NULL,
    "priceFactor" real NOT NULL
);


ALTER TABLE public."MovieSessionMultiFactor" OWNER TO postgres;

--
-- Name: MovieSessionMultiFactor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MovieSessionMultiFactor_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MovieSessionMultiFactor_id_seq" OWNER TO postgres;

--
-- Name: MovieSessionMultiFactor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MovieSessionMultiFactor_id_seq" OWNED BY public."MovieSessionMultiFactor".id;


--
-- Name: MovieSession_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MovieSession_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MovieSession_id_seq" OWNER TO postgres;

--
-- Name: MovieSession_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MovieSession_id_seq" OWNED BY public."MovieSession".id;


--
-- Name: RTSession; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RTSession" (
    id integer NOT NULL,
    "hashedRt" text NOT NULL,
    "rtExpDate" timestamp(3) without time zone NOT NULL,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."RTSession" OWNER TO postgres;

--
-- Name: RTSession_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RTSession_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."RTSession_id_seq" OWNER TO postgres;

--
-- Name: RTSession_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RTSession_id_seq" OWNED BY public."RTSession".id;


--
-- Name: Seat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Seat" (
    id integer NOT NULL,
    "row" integer NOT NULL,
    col integer NOT NULL
);


ALTER TABLE public."Seat" OWNER TO postgres;

--
-- Name: SeatOnBooking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SeatOnBooking" (
    "bookingId" integer NOT NULL,
    "seatId" integer NOT NULL
);


ALTER TABLE public."SeatOnBooking" OWNER TO postgres;

--
-- Name: SeatOnCinemaHall; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SeatOnCinemaHall" (
    "seatId" integer NOT NULL,
    "typeSeatId" integer NOT NULL,
    "cinemaHallId" integer NOT NULL
);


ALTER TABLE public."SeatOnCinemaHall" OWNER TO postgres;

--
-- Name: Seat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Seat_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Seat_id_seq" OWNER TO postgres;

--
-- Name: Seat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Seat_id_seq" OWNED BY public."Seat".id;


--
-- Name: TypeSeat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TypeSeat" (
    id integer NOT NULL,
    type public."TypeSeatEnum" NOT NULL
);


ALTER TABLE public."TypeSeat" OWNER TO postgres;

--
-- Name: TypeSeat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."TypeSeat_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TypeSeat_id_seq" OWNER TO postgres;

--
-- Name: TypeSeat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."TypeSeat_id_seq" OWNED BY public."TypeSeat".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text,
    username text,
    "firstName" text,
    "lastName" text,
    avatar text,
    "hashedPassword" text,
    role public."RoleEnum" DEFAULT 'USER'::public."RoleEnum" NOT NULL,
    gender public."GenderEnum",
    language public."LanguageEnum" DEFAULT 'EN'::public."LanguageEnum" NOT NULL,
    provider public."AuthProviderEnum" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    CONSTRAINT either_email_username CHECK (((email IS NOT NULL) OR (username IS NOT NULL)))
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: Booking id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking" ALTER COLUMN id SET DEFAULT nextval('public."Booking_id_seq"'::regclass);


--
-- Name: Cinema id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Cinema" ALTER COLUMN id SET DEFAULT nextval('public."Cinema_id_seq"'::regclass);


--
-- Name: CinemaHall id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CinemaHall" ALTER COLUMN id SET DEFAULT nextval('public."CinemaHall_id_seq"'::regclass);


--
-- Name: MovieRecord id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieRecord" ALTER COLUMN id SET DEFAULT nextval('public."MovieRecord_id_seq"'::regclass);


--
-- Name: MovieSession id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieSession" ALTER COLUMN id SET DEFAULT nextval('public."MovieSession_id_seq"'::regclass);


--
-- Name: MovieSessionMultiFactor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieSessionMultiFactor" ALTER COLUMN id SET DEFAULT nextval('public."MovieSessionMultiFactor_id_seq"'::regclass);


--
-- Name: RTSession id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RTSession" ALTER COLUMN id SET DEFAULT nextval('public."RTSession_id_seq"'::regclass);


--
-- Name: Seat id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Seat" ALTER COLUMN id SET DEFAULT nextval('public."Seat_id_seq"'::regclass);


--
-- Name: TypeSeat id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TypeSeat" ALTER COLUMN id SET DEFAULT nextval('public."TypeSeat_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Data for Name: Booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Booking" (id, "userId", "totalPrice", currency, "movieSessionId", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Booking" (id, "userId", "totalPrice", currency, "movieSessionId", "createdAt", "updatedAt") FROM '$$PATH$$/3510.dat';

--
-- Data for Name: Cinema; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Cinema" (id, name, address, city) FROM stdin;
\.
COPY public."Cinema" (id, name, address, city) FROM '$$PATH$$/3503.dat';

--
-- Data for Name: CinemaHall; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CinemaHall" (id, "cinemaId", "hallType", name) FROM stdin;
\.
COPY public."CinemaHall" (id, "cinemaId", "hallType", name) FROM '$$PATH$$/3501.dat';

--
-- Data for Name: MovieOnCinema; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MovieOnCinema" ("cinemaId", "movieId") FROM stdin;
\.
COPY public."MovieOnCinema" ("cinemaId", "movieId") FROM '$$PATH$$/3504.dat';

--
-- Data for Name: MovieRecord; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MovieRecord" (id, "imdbId") FROM stdin;
\.
COPY public."MovieRecord" (id, "imdbId") FROM '$$PATH$$/3506.dat';

--
-- Data for Name: MovieSession; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MovieSession" (id, price, currency, "startDate", "endDate", "movieId", "cinemaHallId") FROM stdin;
\.
COPY public."MovieSession" (id, price, currency, "startDate", "endDate", "movieId", "cinemaHallId") FROM '$$PATH$$/3508.dat';

--
-- Data for Name: MovieSessionMultiFactor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MovieSessionMultiFactor" (id, "movieSessionId", "typeSeatId", "priceFactor") FROM stdin;
\.
COPY public."MovieSessionMultiFactor" (id, "movieSessionId", "typeSeatId", "priceFactor") FROM '$$PATH$$/3518.dat';

--
-- Data for Name: RTSession; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RTSession" (id, "hashedRt", "rtExpDate", "userAgent", "createdAt", "updatedAt", "userId") FROM stdin;
\.
COPY public."RTSession" (id, "hashedRt", "rtExpDate", "userAgent", "createdAt", "updatedAt", "userId") FROM '$$PATH$$/3499.dat';

--
-- Data for Name: Seat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Seat" (id, "row", col) FROM stdin;
\.
COPY public."Seat" (id, "row", col) FROM '$$PATH$$/3513.dat';

--
-- Data for Name: SeatOnBooking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SeatOnBooking" ("bookingId", "seatId") FROM stdin;
\.
COPY public."SeatOnBooking" ("bookingId", "seatId") FROM '$$PATH$$/3511.dat';

--
-- Data for Name: SeatOnCinemaHall; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SeatOnCinemaHall" ("seatId", "typeSeatId", "cinemaHallId") FROM stdin;
\.
COPY public."SeatOnCinemaHall" ("seatId", "typeSeatId", "cinemaHallId") FROM '$$PATH$$/3514.dat';

--
-- Data for Name: TypeSeat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TypeSeat" (id, type) FROM stdin;
\.
COPY public."TypeSeat" (id, type) FROM '$$PATH$$/3516.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, username, "firstName", "lastName", avatar, "hashedPassword", role, gender, language, provider, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."User" (id, email, username, "firstName", "lastName", avatar, "hashedPassword", role, gender, language, provider, "createdAt", "updatedAt") FROM '$$PATH$$/3497.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3495.dat';

--
-- Name: Booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Booking_id_seq"', 1, false);


--
-- Name: CinemaHall_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CinemaHall_id_seq"', 4, true);


--
-- Name: Cinema_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Cinema_id_seq"', 2, true);


--
-- Name: MovieRecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MovieRecord_id_seq"', 100, true);


--
-- Name: MovieSessionMultiFactor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MovieSessionMultiFactor_id_seq"', 9, true);


--
-- Name: MovieSession_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MovieSession_id_seq"', 3, true);


--
-- Name: RTSession_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RTSession_id_seq"', 1, true);


--
-- Name: Seat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Seat_id_seq"', 100, true);


--
-- Name: TypeSeat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."TypeSeat_id_seq"', 3, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 1, true);


--
-- Name: Booking Booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_pkey" PRIMARY KEY (id);


--
-- Name: CinemaHall CinemaHall_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CinemaHall"
    ADD CONSTRAINT "CinemaHall_pkey" PRIMARY KEY (id);


--
-- Name: Cinema Cinema_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Cinema"
    ADD CONSTRAINT "Cinema_pkey" PRIMARY KEY (id);


--
-- Name: MovieOnCinema MovieOnCinema_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieOnCinema"
    ADD CONSTRAINT "MovieOnCinema_pkey" PRIMARY KEY ("cinemaId", "movieId");


--
-- Name: MovieRecord MovieRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieRecord"
    ADD CONSTRAINT "MovieRecord_pkey" PRIMARY KEY (id);


--
-- Name: MovieSessionMultiFactor MovieSessionMultiFactor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieSessionMultiFactor"
    ADD CONSTRAINT "MovieSessionMultiFactor_pkey" PRIMARY KEY (id);


--
-- Name: MovieSession MovieSession_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieSession"
    ADD CONSTRAINT "MovieSession_pkey" PRIMARY KEY (id);


--
-- Name: RTSession RTSession_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RTSession"
    ADD CONSTRAINT "RTSession_pkey" PRIMARY KEY (id);


--
-- Name: SeatOnBooking SeatOnBooking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeatOnBooking"
    ADD CONSTRAINT "SeatOnBooking_pkey" PRIMARY KEY ("bookingId", "seatId");


--
-- Name: SeatOnCinemaHall SeatOnCinemaHall_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeatOnCinemaHall"
    ADD CONSTRAINT "SeatOnCinemaHall_pkey" PRIMARY KEY ("seatId", "cinemaHallId");


--
-- Name: Seat Seat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Seat"
    ADD CONSTRAINT "Seat_pkey" PRIMARY KEY (id);


--
-- Name: TypeSeat TypeSeat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TypeSeat"
    ADD CONSTRAINT "TypeSeat_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: CinemaHall_name_cinemaId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CinemaHall_name_cinemaId_key" ON public."CinemaHall" USING btree (name, "cinemaId");


--
-- Name: Cinema_name_address_city_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Cinema_name_address_city_key" ON public."Cinema" USING btree (name, address, city);


--
-- Name: MovieRecord_imdbId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "MovieRecord_imdbId_key" ON public."MovieRecord" USING btree ("imdbId");


--
-- Name: RTSession_hashedRt_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "RTSession_hashedRt_userId_key" ON public."RTSession" USING btree ("hashedRt", "userId");


--
-- Name: Seat_row_col_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Seat_row_col_key" ON public."Seat" USING btree ("row", col);


--
-- Name: TypeSeat_type_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TypeSeat_type_key" ON public."TypeSeat" USING btree (type);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: Booking Booking_movieSessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_movieSessionId_fkey" FOREIGN KEY ("movieSessionId") REFERENCES public."MovieSession"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Booking Booking_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CinemaHall CinemaHall_cinemaId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CinemaHall"
    ADD CONSTRAINT "CinemaHall_cinemaId_fkey" FOREIGN KEY ("cinemaId") REFERENCES public."Cinema"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MovieOnCinema MovieOnCinema_cinemaId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieOnCinema"
    ADD CONSTRAINT "MovieOnCinema_cinemaId_fkey" FOREIGN KEY ("cinemaId") REFERENCES public."Cinema"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MovieOnCinema MovieOnCinema_movieId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieOnCinema"
    ADD CONSTRAINT "MovieOnCinema_movieId_fkey" FOREIGN KEY ("movieId") REFERENCES public."MovieRecord"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MovieSessionMultiFactor MovieSessionMultiFactor_movieSessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieSessionMultiFactor"
    ADD CONSTRAINT "MovieSessionMultiFactor_movieSessionId_fkey" FOREIGN KEY ("movieSessionId") REFERENCES public."MovieSession"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MovieSessionMultiFactor MovieSessionMultiFactor_typeSeatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieSessionMultiFactor"
    ADD CONSTRAINT "MovieSessionMultiFactor_typeSeatId_fkey" FOREIGN KEY ("typeSeatId") REFERENCES public."TypeSeat"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MovieSession MovieSession_cinemaHallId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieSession"
    ADD CONSTRAINT "MovieSession_cinemaHallId_fkey" FOREIGN KEY ("cinemaHallId") REFERENCES public."CinemaHall"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MovieSession MovieSession_movieId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MovieSession"
    ADD CONSTRAINT "MovieSession_movieId_fkey" FOREIGN KEY ("movieId") REFERENCES public."MovieRecord"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RTSession RTSession_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RTSession"
    ADD CONSTRAINT "RTSession_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SeatOnBooking SeatOnBooking_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeatOnBooking"
    ADD CONSTRAINT "SeatOnBooking_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SeatOnBooking SeatOnBooking_seatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeatOnBooking"
    ADD CONSTRAINT "SeatOnBooking_seatId_fkey" FOREIGN KEY ("seatId") REFERENCES public."Seat"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SeatOnCinemaHall SeatOnCinemaHall_cinemaHallId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeatOnCinemaHall"
    ADD CONSTRAINT "SeatOnCinemaHall_cinemaHallId_fkey" FOREIGN KEY ("cinemaHallId") REFERENCES public."CinemaHall"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SeatOnCinemaHall SeatOnCinemaHall_seatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeatOnCinemaHall"
    ADD CONSTRAINT "SeatOnCinemaHall_seatId_fkey" FOREIGN KEY ("seatId") REFERENCES public."Seat"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SeatOnCinemaHall SeatOnCinemaHall_typeSeatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeatOnCinemaHall"
    ADD CONSTRAINT "SeatOnCinemaHall_typeSeatId_fkey" FOREIGN KEY ("typeSeatId") REFERENCES public."TypeSeat"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

